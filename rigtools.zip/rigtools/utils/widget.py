import bpy
import hashlib
import math

from rigtools.preferences import get_preferences
from rigtools.utils.naming import generate_widget_name

fk_widget_types = [
	('CIRCLE', 'Circle', 'Create a circle widget'),
	('RECTANGLE', 'Rectangle', 'Create a rectangle widget'),
	('FK', 'FK Shape', 'Create a FK widget'),
	('BOX', 'Box', 'Create a box widget'),
	('PILL', 'Pill', 'Create a pill widget'),
	('SPHERE', 'Sphere', 'Create a sphere widget'),
	('SHOULDER', 'Shoulder', 'Create a shoulder widget'),
	('IK', 'IK Shape', 'Create an IK widget'),
	('NONE', 'None', 'No widget'),
]

LIMB_FK_WIRE_WIDTH = 1.5
CONTROL_WIRE_WIDTH = 2.0
IK_WIRE_WIDTH = 2.0
TORSO_FK_WIRE_WIDTH = 1.5
ROOT_WIRE_WIDTH = 1.5

master_widget_types = [item for item in fk_widget_types if item[0] != 'NONE']

# Widgets that should keep their proportions when scaled (everything else scales X/Z only, keeping bone length)
UNIFORM_SCALE_WIDGETS = {'SPHERE'}

FK_WIDGET_TAPER = 0.2 # tip widget ends at 80% size

def chain_widget_scales(lengths, *, normalize=False, taper=False):
	"""Per-bone widget scale factor for a chain.
	normalize: size every widget to the chain's average bone length.
	taper: shrink widgets toward the tip (only with normalize)."""
	n = len(lengths)
	if not normalize:
		return [1.0] * n
	avg = sum(lengths) / n if n else 0.0
	scales = []
	for i, length in enumerate(lengths):
		s = avg / length
		if taper and n > 1:
			s *= 1.0 - FK_WIDGET_TAPER * i / (n - 1)
		scales.append(s)
	return scales

def widget_scale_xyz(widget_type, s):
	"""custom_shape_scale_xyz for a scale factor."""
	if widget_type in UNIFORM_SCALE_WIDGETS:
		return (s, s, s)
	return (s, 1.0, s)

# Custom property marking a shared standard widget; the value is the name it was created with,
# so it's still found after a rename, and never matches another rig's widget
STANDARD_WIDGET_KEY = "rigtools_widget"
# Custom property holding a hash of the mesh as RigTools generated it, to tell when it's been edited
STANDARD_WIDGET_MESH_KEY = "rigtools_widget_mesh"

DEFAULT_WIDGET_CLASSES = {'FK': "FK", 'IK': "IK"}

# Every widget type _widget_creator can build
STANDARD_WIDGET_TYPES = (
	'CIRCLE', 'RECTANGLE', 'FK', 'BOX', 'PILL', 'SHOULDER', 'IK', 'SPHERE',
	'LINE', 'TWIST', 'CHEST', 'ROLL', 'PADDLE', 'ROOT', 'GEAR',
)

def is_standard_widget(obj):
	return obj is not None and STANDARD_WIDGET_KEY in obj

def default_widget_class(widget_type):
	return DEFAULT_WIDGET_CLASSES.get(widget_type, widget_type.title())

def standard_widget_name(context, widget_type, widget_class=None):
	return generate_widget_name(widget_class or default_widget_class(widget_type), context)

def find_standard_widget(context, widget_type, widget_class=None):
	"""The shared widget for this class, or None if it hasn't been created"""
	if widget_type == 'NONE':
		return None
	name = standard_widget_name(context, widget_type, widget_class)
	wgt = bpy.data.objects.get(name)
	if wgt is None or wgt.get(STANDARD_WIDGET_KEY) != name:
		wgt = next((o for o in bpy.data.objects if o.get(STANDARD_WIDGET_KEY) == name), None)
	return wgt

def get_standard_widget(context, widget_type, widget_class=None):
	"""The one shared widget for this class, created the first time it's needed"""
	if widget_type == 'NONE':
		return None
	wgt = find_standard_widget(context, widget_type, widget_class)
	if wgt is None:
		name = standard_widget_name(context, widget_type, widget_class)
		wgt = _create_widget(context, widget_type, name)
		wgt[STANDARD_WIDGET_KEY] = name
		wgt[STANDARD_WIDGET_MESH_KEY] = mesh_fingerprint(wgt.data)
	return wgt

def restore_standard_widget(context, widget_type, widget_class=None):
	"""Put the shared widget's mesh back the way RigTools generates it, undoing any edits"""
	wgt = get_standard_widget(context, widget_type, widget_class)
	if wgt is None:
		return None
	fresh = _widget_creator(widget_type)(wgt.name)
	old_mesh = wgt.data
	wgt.data = fresh.data
	bpy.data.objects.remove(fresh)
	if old_mesh.users == 0:
		bpy.data.meshes.remove(old_mesh)
	wgt.data.name = wgt.name
	wgt[STANDARD_WIDGET_MESH_KEY] = mesh_fingerprint(wgt.data)
	return wgt

def mesh_fingerprint(mesh):
	"""Hash of the mesh's shape, rounded so float noise doesn't count as an edit"""
	data = hashlib.sha1()
	for vert in mesh.vertices:
		data.update(repr(tuple(round(c, 4) for c in vert.co)).encode())
	for edge in mesh.edges:
		data.update(repr(tuple(edge.vertices)).encode())
	return data.hexdigest()

def is_widget_mesh_edited(wgt):
	"""Widgets made before the hash was stored count as edited, so they can still be restored"""
	return wgt.get(STANDARD_WIDGET_MESH_KEY) != mesh_fingerprint(wgt.data)

def unused_standard_widgets():
	"""Shared widgets that no bone on any rig uses. Only RigTools' own widgets: a user's objects are never included"""
	used = {
		pose_bone.custom_shape.name
		for obj in bpy.data.objects if obj.type == 'ARMATURE' and obj.pose
		for pose_bone in obj.pose.bones if pose_bone.custom_shape
	}
	return [obj for obj in bpy.data.objects if is_standard_widget(obj) and obj.name not in used]

def remove_widget(wgt):
	mesh = wgt.data
	bpy.data.objects.remove(wgt)
	if mesh is not None and mesh.users == 0:
		bpy.data.meshes.remove(mesh)

def _create_widget(context, widget_type, widget_name):
	collection = _get_widget_collection(context, get_preferences(context).widget_collection)
	wgt = _widget_creator(widget_type)(widget_name)
	collection.objects.link(wgt)
	return wgt

def _widget_creator(widget_type):
	match widget_type:
		case 'CIRCLE':
			creator = _create_circle_widget
		case 'RECTANGLE':
			creator = _create_rectangle_widget
		case 'FK':
			creator = _create_fk_shape_widget
		case 'BOX':
			creator = _create_box_widget
		case 'PILL':
			creator = _create_pill_widget
		case 'SHOULDER':
			creator = _create_shoulder_widget
		case 'IK':
			creator = _create_ik_widget
		case 'SPHERE':
			creator = _create_sphere_widget
		case 'LINE':
			creator = _create_line_widget
		case 'TWIST':
			creator = _create_twist_widget
		case 'CHEST':
			creator = _create_chest_widget
		case 'ROLL':
			creator = _create_roll_widget
		case 'PADDLE':
			creator = _create_paddle_widget
		case 'ROOT':
			creator = _create_root_widget
		case 'GEAR':
			creator = _create_gear_widget
		case _:
			raise ValueError(f"Invalid widget type: {widget_type}")
	return creator

def apply_widget(context, pose_bone, widget_type, widget_class=None):
	wgt = get_standard_widget(context, widget_type, widget_class)
	pose_bone.custom_shape = wgt
	return wgt

def _get_widget_collection(context, collection_name):
	coll = bpy.data.collections.get(collection_name)
	if not coll:
		coll = bpy.data.collections.new(collection_name)
		context.scene.collection.children.link(coll)
		coll.hide_viewport = True
		coll.hide_render = True
	return coll

def _create_sphere_widget(widget_name):    
	verts = []
	edges = []
	segments = 12
	
	for axis in ['XY', 'XZ', 'YZ']:
		start_idx = len(verts)
		for i in range(segments):
			angle = (2 * math.pi * i) / segments
			cos_a = math.cos(angle) * 0.5
			sin_a = math.sin(angle) * 0.5
			
			match axis:
				case 'XY':
					verts.append((cos_a, sin_a, 0.0))
				case 'XZ':
					verts.append((cos_a, 0.0, sin_a))
				case 'YZ':
					verts.append((0.0, cos_a, sin_a))
					
			next_i = (i + 1) % segments
			edges.append((start_idx + i, start_idx + next_i))
			
	mesh = bpy.data.meshes.new(widget_name)
	mesh.from_pydata(verts, edges, [])
	mesh.update()
	
	wgt = bpy.data.objects.new(widget_name, mesh)
	
	return wgt

def _create_circle_widget(widget_name):
	verts = []
	edges = []
	segments = 16
	
	for i in range(segments):
		angle = (2 * math.pi * i) / segments
		verts.append((math.cos(angle) * 0.5, 0.5, math.sin(angle) * 0.5))
		edges.append((i, (i + 1) % segments))
		
	mesh = bpy.data.meshes.new(widget_name)
	mesh.from_pydata(verts, edges, [])
	mesh.update()
	
	wgt = bpy.data.objects.new(widget_name, mesh)
	return wgt

def _create_line_widget(widget_name):
	verts = [(0.0, 0.0, 0.0), (0.0, 1.0, 0.0)]
	edges = [(0, 1)]

	mesh = bpy.data.meshes.new(widget_name)
	mesh.from_pydata(verts, edges, [])
	mesh.update()

	wgt = bpy.data.objects.new(widget_name, mesh)
	return wgt

def _create_box_widget(widget_name, size_x=0.85, size_y=1.0, size_z=0.4):
	hx, hz = size_x * 0.5, size_z * 0.5
	verts = [
		(-hx, 0, -hz),
		( hx, 0, -hz),
		( hx, size_y, -hz),
		(-hx, size_y, -hz),
		(-hx, 0,  hz),
		( hx, 0,  hz),
		( hx, size_y,  hz),
		(-hx, size_y,  hz),
	]
	edges = [
		(0, 1), (1, 2), (2, 3), (3, 0),
		(4, 5), (5, 6), (6, 7), (7, 4),
		(0, 4), (1, 5), (2, 6), (3, 7),
	]
	mesh = bpy.data.meshes.new(widget_name)
	mesh.from_pydata(verts, edges, [])
	mesh.update()
	wgt = bpy.data.objects.new(widget_name, mesh)
	return wgt

def _create_rectangle_widget(widget_name, width = 0.15, height = 0.90):
	verts = [
		(0.0, (1.0 - height)/2, -width/2),
		(0.0, (1.0 - height)/2, width/2),
		(0.0, (1.0 + height)/2, width/2),
		(0.0, (1.0 + height)/2, -width/2),
	]
	edges = [(0, 1), (1, 2), (2, 3), (3, 0)]
	mesh = bpy.data.meshes.new(widget_name)
	mesh.from_pydata(verts, edges, [])
	mesh.update()
	wgt = bpy.data.objects.new(widget_name, mesh)
	return wgt

def _create_fk_shape_widget(widget_name, radius = 0.25):
	verts = [(0.0, 0.0, 0.0), (0.0, 1.0, 0.0)]
	edges = [(0, 1)]

	segments = 16
	
	for i in range(segments):
		angle = (2 * math.pi * i) / segments
		verts.append((math.cos(angle) * radius, 0.5, math.sin(angle) * radius))
		edges.append((i + 2, (i + 1) % segments + 2))	

	mesh = bpy.data.meshes.new(widget_name)
	mesh.from_pydata(verts, edges, [])
	mesh.update()
	wgt = bpy.data.objects.new(widget_name, mesh)
	return wgt

def _create_twist_widget(widget_name):
	"""Two parallel arc rings with opposing Vs in each gap:  > <  """
	verts = [
		(-0.191342, 0.054932, -0.461940),
		(-0.277785, 0.054932, -0.415735),
		(-0.353553, 0.054932, -0.353553),
		(-0.415735, 0.054932, -0.277785),
		(-0.461940, 0.054932, -0.191342),
		(-0.461940, 0.054932, 0.191342),
		(-0.415735, 0.054932, 0.277785),
		(-0.353553, 0.054932, 0.353553),
		(-0.277785, 0.054932, 0.415735),
		(-0.191342, 0.054932, 0.461940),
		(0.191342, 0.054932, -0.461940),
		(0.277785, 0.054932, -0.415735),
		(0.353553, 0.054932, -0.353553),
		(0.415735, 0.054932, -0.277785),
		(0.461940, 0.054932, -0.191342),
		(0.461940, 0.054932, 0.191342),
		(0.415735, 0.054932, 0.277785),
		(0.353553, 0.054932, 0.353553),
		(0.277785, 0.054932, 0.415735),
		(0.191342, 0.054932, 0.461940),
		(0.191342, -0.054932, -0.461940),
		(0.277785, -0.054932, -0.415735),
		(0.353553, -0.054932, -0.353553),
		(-0.191342, -0.054932, -0.461940),
		(-0.277785, -0.054932, -0.415735),
		(-0.353553, -0.054932, -0.353553),
		(-0.415735, -0.054932, -0.277785),
		(-0.461940, -0.054932, -0.191342),
		(-0.461940, -0.054932, 0.191342),
		(-0.415735, -0.054932, 0.277785),
		(-0.353553, -0.054932, 0.353553),
		(-0.277785, -0.054932, 0.415735),
		(-0.191342, -0.054932, 0.461940),
		(0.415735, -0.054932, -0.277785),
		(0.461940, -0.054932, -0.191342),
		(0.461940, -0.054932, 0.191342),
		(0.415735, -0.054932, 0.277785),
		(0.353553, -0.054932, 0.353553),
		(0.277785, -0.054932, 0.415735),
		(0.191342, -0.054932, 0.461940),
		(0.097545, -0.000000, -0.490393),
		(0.490393, -0.000000, -0.097545),
		(0.490393, 0.000000, 0.097545),
		(0.097545, 0.000000, 0.490393),
		(-0.097545, -0.000000, -0.490393),
		(-0.490393, -0.000000, -0.097545),
		(-0.490393, 0.000000, 0.097545),
		(-0.097545, 0.000000, 0.490393),
	]
	edges = [
		(1, 0),
		(2, 1),
		(3, 2),
		(4, 3),
		(6, 5),
		(7, 6),
		(8, 7),
		(9, 8),
		(11, 10),
		(12, 11),
		(13, 12),
		(14, 13),
		(16, 15),
		(17, 16),
		(18, 17),
		(19, 18),
		(20, 40),
		(21, 20),
		(22, 21),
		(33, 22),
		(23, 44),
		(24, 23),
		(25, 24),
		(26, 25),
		(27, 26),
		(29, 28),
		(30, 29),
		(31, 30),
		(32, 31),
		(28, 46),
		(5, 46),
		(34, 33),
		(36, 35),
		(37, 36),
		(38, 37),
		(39, 38),
		(35, 42),
		(15, 42),
		(10, 40),
		(14, 41),
		(34, 41),
		(19, 43),
		(39, 43),
		(0, 44),
		(4, 45),
		(27, 45),
		(9, 47),
		(32, 47),
	]
	mesh = bpy.data.meshes.new(widget_name)
	mesh.from_pydata(verts, edges, [])
	mesh.update()
	wgt = bpy.data.objects.new(widget_name, mesh)
	return wgt


def _create_chest_widget(widget_name):
	verts = [
	(0.000000, -0.745914, -0.118223),
	(-0.195090, -0.731528, -0.100247),
	(-0.382683, -0.688923, -0.043049),
	(-0.555570, -0.619737, 0.060735),
	(-0.707107, -0.526628, 0.181042),
	(-0.831470, -0.413175, 0.298476),
	(-0.923880, -0.283737, 0.392751),
	(-0.980785, -0.143288, 0.461894),
	(-1.000000, 0.002773, 0.488856),
	(-0.980785, 0.148835, 0.461894),
	(-0.923880, 0.289284, 0.392751),
	(-0.831470, 0.418722, 0.298476),
	(-0.707107, 0.532175, 0.181043),
	(-0.555570, 0.625284, 0.060735),
	(-0.382683, 0.694470, -0.043049),
	(-0.195090, 0.737075, -0.100247),
	(0.000000, 0.751461, -0.118223),
	(0.195090, 0.737075, -0.100247),
	(0.382683, 0.694470, -0.043049),
	(0.555570, 0.625284, 0.060735),
	(0.707107, 0.532175, 0.181043),
	(0.831470, 0.418722, 0.298476),
	(0.923880, 0.289284, 0.392751),
	(0.980785, 0.148835, 0.461894),
	(1.000000, 0.002773, 0.488856),
	(0.980785, -0.143288, 0.461894),
	(0.923880, -0.283737, 0.392751),
	(0.831470, -0.413175, 0.298476),
	(0.707107, -0.526628, 0.181042),
	(0.555570, -0.619737, 0.060735),
	(0.382683, -0.688923, -0.043049),
	(0.195090, -0.731528, -0.100247),
	]
	edges = [
	(1, 0),
	(2, 1),
	(3, 2),
	(4, 3),
	(5, 4),
	(6, 5),
	(7, 6),
	(8, 7),
	(9, 8),
	(10, 9),
	(11, 10),
	(12, 11),
	(13, 12),
	(14, 13),
	(15, 14),
	(16, 15),
	(17, 16),
	(18, 17),
	(19, 18),
	(20, 19),
	(21, 20),
	(22, 21),
	(23, 22),
	(24, 23),
	(25, 24),
	(26, 25),
	(27, 26),
	(28, 27),
	(29, 28),
	(30, 29),
	(31, 30),
	(0, 31),
	]
	mesh = bpy.data.meshes.new(widget_name)
	mesh.from_pydata(verts, edges, [])
	mesh.update()
	wgt = bpy.data.objects.new(widget_name, mesh)
	return wgt	

def _create_roll_widget(widget_name):
	verts = [
	(0.000000, 0.284248, -0.226397),
	(0.000000, 0.316874, -0.234569),
	(0.000000, 0.348541, -0.245900),
	(0.000000, 0.378947, -0.260282),
	(0.000000, 0.407795, -0.277572),
	(0.000000, 0.434811, -0.297608),
	(0.000000, 0.459732, -0.320196),
	(0.000000, 0.482319, -0.345117),
	(0.000000, 0.502356, -0.372132),
	(0.000000, 0.519646, -0.400981),
	(-0.000000, 0.534028, -0.431386),
	(-0.000000, 0.545359, -0.463054),
	(-0.000000, 0.553531, -0.495680),
	(-0.000000, 0.558466, -0.528950),
	(-0.000000, 0.560116, -0.562544),
	(-0.000000, 0.558466, -0.596137),
	(-0.000000, 0.553531, -0.629408),
	(-0.000000, 0.545359, -0.662034),
	(-0.000000, 0.534028, -0.693702),
	(-0.000000, 0.519646, -0.724107),
	(-0.000000, 0.502356, -0.752956),
	(-0.000000, 0.482319, -0.779971),
	(-0.000000, 0.459732, -0.804892),
	(-0.000000, 0.434811, -0.827480),
	(-0.000000, 0.407796, -0.847516),
	(-0.000000, 0.378947, -0.864807),
	(-0.000000, 0.348542, -0.879187),
	(-0.000000, 0.316874, -0.890519),
	(-0.000000, 0.284248, -0.898691),
	(0.000000, 0.277839, -0.258614),
	(0.000000, 0.307338, -0.266003),
	(0.000000, 0.335972, -0.276248),
	(0.000000, 0.363462, -0.289250),
	(0.000000, 0.389547, -0.304885),
	(0.000000, 0.413972, -0.323000),
	(0.000000, 0.436505, -0.343423),
	(0.000000, 0.456928, -0.365956),
	(0.000000, 0.475043, -0.390381),
	(0.000000, 0.490677, -0.416466),
	(0.000000, 0.503680, -0.443956),
	(-0.000000, 0.513925, -0.472590),
	(-0.000000, 0.521314, -0.502089),
	(-0.000000, 0.525777, -0.532170),
	(-0.000000, 0.527268, -0.562544),
	(-0.000000, 0.525777, -0.592918),
	(-0.000000, 0.521314, -0.622999),
	(-0.000000, 0.513925, -0.652499),
	(-0.000000, 0.503680, -0.681132),
	(-0.000000, 0.490677, -0.708623),
	(-0.000000, 0.475043, -0.734707),
	(-0.000000, 0.456928, -0.759132),
	(-0.000000, 0.436505, -0.781665),
	(-0.000000, 0.413972, -0.802088),
	(-0.000000, 0.389547, -0.820204),
	(-0.000000, 0.363462, -0.835838),
	(-0.000000, 0.335972, -0.848840),
	(-0.000000, 0.307338, -0.859085),
	(-0.000000, 0.277839, -0.866475),
	(0.000000, 0.286568, -0.214734),
	(-0.000000, 0.286568, -0.910354),
	(0.000000, 0.275631, -0.269717),
	(-0.000000, 0.275631, -0.855371),
	(0.000000, 0.233378, -0.236978),
	(-0.000000, 0.233378, -0.888110),
	(0.336147, 0.284248, -0.562544),
	(0.327974, 0.316874, -0.562544),
	(0.316643, 0.348541, -0.562544),
	(0.302263, 0.378947, -0.562544),
	(0.284971, 0.407795, -0.562544),
	(0.264936, 0.434811, -0.562544),
	(0.242349, 0.459732, -0.562544),
	(0.217427, 0.482319, -0.562544),
	(0.190412, 0.502356, -0.562544),
	(0.161563, 0.519646, -0.562544),
	(0.131158, 0.534028, -0.562544),
	(0.099490, 0.545359, -0.562544),
	(0.066863, 0.553531, -0.562544),
	(0.033594, 0.558466, -0.562544),
	(-0.000000, 0.560116, -0.562544),
	(-0.033594, 0.558466, -0.562544),
	(-0.066863, 0.553531, -0.562544),
	(-0.099490, 0.545359, -0.562544),
	(-0.131158, 0.534028, -0.562544),
	(-0.161563, 0.519646, -0.562544),
	(-0.190412, 0.502356, -0.562544),
	(-0.217427, 0.482319, -0.562544),
	(-0.242349, 0.459732, -0.562544),
	(-0.264936, 0.434811, -0.562544),
	(-0.284971, 0.407796, -0.562544),
	(-0.302263, 0.378947, -0.562544),
	(-0.316643, 0.348542, -0.562544),
	(-0.327974, 0.316874, -0.562544),
	(-0.336147, 0.284248, -0.562544),
	(0.303930, 0.277839, -0.562544),
	(0.296541, 0.307338, -0.562544),
	(0.286296, 0.335972, -0.562544),
	(0.273294, 0.363462, -0.562544),
	(0.257660, 0.389547, -0.562544),
	(0.239544, 0.413972, -0.562544),
	(0.219122, 0.436505, -0.562544),
	(0.196589, 0.456928, -0.562544),
	(0.172162, 0.475043, -0.562544),
	(0.146079, 0.490677, -0.562544),
	(0.118587, 0.503680, -0.562544),
	(0.089955, 0.513925, -0.562544),
	(0.060456, 0.521314, -0.562544),
	(0.030374, 0.525777, -0.562544),
	(-0.000000, 0.527268, -0.562544),
	(-0.030374, 0.525777, -0.562544),
	(-0.060456, 0.521314, -0.562544),
	(-0.089955, 0.513925, -0.562544),
	(-0.118587, 0.503680, -0.562544),
	(-0.146079, 0.490677, -0.562544),
	(-0.172162, 0.475043, -0.562544),
	(-0.196589, 0.456928, -0.562544),
	(-0.219122, 0.436505, -0.562544),
	(-0.239544, 0.413972, -0.562544),
	(-0.257660, 0.389547, -0.562544),
	(-0.273294, 0.363462, -0.562544),
	(-0.286296, 0.335972, -0.562544),
	(-0.296541, 0.307338, -0.562544),
	(-0.303930, 0.277839, -0.562544),
	(0.347810, 0.286568, -0.562544),
	(-0.347810, 0.286568, -0.562544),
	(0.292827, 0.275631, -0.562544),
	(-0.292827, 0.275631, -0.562544),
	(0.325567, 0.233378, -0.562544),
	(-0.325567, 0.233378, -0.562544),
	]
	edges = [
	(1, 0),
	(2, 1),
	(3, 2),
	(4, 3),
	(5, 4),
	(6, 5),
	(7, 6),
	(8, 7),
	(9, 8),
	(10, 9),
	(11, 10),
	(12, 11),
	(13, 12),
	(14, 13),
	(15, 14),
	(16, 15),
	(17, 16),
	(18, 17),
	(19, 18),
	(20, 19),
	(21, 20),
	(22, 21),
	(23, 22),
	(24, 23),
	(25, 24),
	(26, 25),
	(27, 26),
	(28, 27),
	(30, 29),
	(31, 30),
	(32, 31),
	(33, 32),
	(34, 33),
	(35, 34),
	(36, 35),
	(37, 36),
	(38, 37),
	(39, 38),
	(40, 39),
	(41, 40),
	(42, 41),
	(43, 42),
	(44, 43),
	(45, 44),
	(46, 45),
	(47, 46),
	(48, 47),
	(49, 48),
	(50, 49),
	(51, 50),
	(52, 51),
	(53, 52),
	(54, 53),
	(55, 54),
	(56, 55),
	(57, 56),
	(28, 59),
	(29, 60),
	(57, 61),
	(59, 63),
	(61, 63),
	(60, 62),
	(58, 62),
	(0, 58),
	(65, 64),
	(66, 65),
	(67, 66),
	(68, 67),
	(69, 68),
	(70, 69),
	(71, 70),
	(72, 71),
	(73, 72),
	(74, 73),
	(75, 74),
	(76, 75),
	(77, 76),
	(78, 77),
	(79, 78),
	(80, 79),
	(81, 80),
	(82, 81),
	(83, 82),
	(84, 83),
	(85, 84),
	(86, 85),
	(87, 86),
	(88, 87),
	(89, 88),
	(90, 89),
	(91, 90),
	(92, 91),
	(94, 93),
	(95, 94),
	(96, 95),
	(97, 96),
	(98, 97),
	(99, 98),
	(100, 99),
	(101, 100),
	(102, 101),
	(103, 102),
	(104, 103),
	(105, 104),
	(106, 105),
	(107, 106),
	(108, 107),
	(109, 108),
	(110, 109),
	(111, 110),
	(112, 111),
	(113, 112),
	(114, 113),
	(115, 114),
	(116, 115),
	(117, 116),
	(118, 117),
	(119, 118),
	(120, 119),
	(121, 120),
	(92, 123),
	(93, 124),
	(121, 125),
	(123, 127),
	(125, 127),
	(124, 126),
	(122, 126),
	(64, 122),
	]
	mesh = bpy.data.meshes.new(widget_name)
	mesh.from_pydata(verts, edges, [])
	mesh.update()
	wgt = bpy.data.objects.new(widget_name, mesh)
	return wgt	

def _create_ik_widget(widget_name):
	verts = [
	(-0.594966, 0.957575, 0.002833),
	(-0.221238, 1.365031, 0.002833),
	(-0.585842, 1.083486, 0.002833),
	(-0.537578, 1.197072, 0.002833),
	(-0.454897, 1.287214, 0.002833),
	(-0.345894, 1.345089, 0.002833),
	(0.221238, 1.365031, 0.002833),
	(0.594966, 0.957575, 0.002833),
	(0.345894, 1.345089, 0.002833),
	(0.454897, 1.287214, 0.002833),
	(0.537578, 1.197072, 0.002833),
	(0.585842, 1.083486, 0.002833),
	(-0.272503, -0.305133, 0.002833),
	(-0.520291, -0.077857, 0.002833),
	(-0.361300, -0.287832, 0.002833),
	(-0.439571, -0.238565, 0.002833),
	(-0.495401, -0.164832, 0.002833),
	(0.272503, -0.305133, 0.002833),
	(0.520291, -0.077857, 0.002833),
	(0.361300, -0.287832, 0.002833),
	(0.439571, -0.238565, 0.002833),
	(0.495401, -0.164832, 0.002833),
	]
	edges = [
	(0, 2),
	(2, 3),
	(3, 4),
	(4, 5),
	(5, 1),
	(6, 8),
	(8, 9),
	(9, 10),
	(10, 11),
	(11, 7),
	(1, 6),
	(12, 14),
	(14, 15),
	(15, 16),
	(16, 13),
	(17, 19),
	(19, 20),
	(20, 21),
	(21, 18),
	(12, 17),
	(13, 0),
	(18, 7),
	]
	mesh = bpy.data.meshes.new(widget_name)
	mesh.from_pydata(verts, edges, [])
	mesh.update()
	wgt = bpy.data.objects.new(widget_name, mesh)
	return wgt	

def _create_pill_widget(widget_name):
	verts = [
	(0.000000, 0.050000, 0.000000),
	(0.000000, 0.125000, -0.075000),
	(0.000000, 0.052556, -0.019411),
	(0.000000, 0.060048, -0.037500),
	(0.000000, 0.071967, -0.053033),
	(0.000000, 0.087500, -0.064952),
	(0.000000, 0.105589, -0.072444),
	(0.000000, 0.050000, 0.000000),
	(0.000000, 0.125000, 0.075000),
	(0.000000, 0.052556, 0.019411),
	(0.000000, 0.060048, 0.037500),
	(0.000000, 0.071967, 0.053033),
	(0.000000, 0.087500, 0.064952),
	(0.000000, 0.105589, 0.072444),
	(0.000000, 0.875000, 0.075000),
	(0.000000, 0.950000, 0.000000),
	(0.000000, 0.894412, 0.072444),
	(0.000000, 0.912500, 0.064952),
	(0.000000, 0.928033, 0.053033),
	(0.000000, 0.939952, 0.037500),
	(0.000000, 0.947444, 0.019411),
	(0.000000, 0.950000, 0.000000),
	(0.000000, 0.875000, -0.075000),
	(0.000000, 0.947444, -0.019411),
	(0.000000, 0.939952, -0.037500),
	(0.000000, 0.928033, -0.053033),
	(0.000000, 0.912500, -0.064952),
	(0.000000, 0.894412, -0.072444),
	]
	edges = [
	(0, 2),
	(2, 3),
	(3, 4),
	(4, 5),
	(5, 6),
	(6, 1),
	(7, 9),
	(9, 10),
	(10, 11),
	(11, 12),
	(12, 13),
	(13, 8),
	(14, 16),
	(16, 17),
	(17, 18),
	(18, 19),
	(19, 20),
	(20, 15),
	(21, 23),
	(23, 24),
	(24, 25),
	(25, 26),
	(26, 27),
	(27, 22),
	(0, 7),
	(1, 22),
	(8, 14),
	(15, 21),
	]
	mesh = bpy.data.meshes.new(widget_name)
	mesh.from_pydata(verts, edges, [])
	mesh.update()
	wgt = bpy.data.objects.new(widget_name, mesh)
	return wgt	

def _create_paddle_widget(widget_name):
	verts = [
	(0.000000, 0.000000, 0.000000),
	(0.000000, 0.800000, 0.000000),
	(0.000000, 0.800000, 0.100000),
	(0.000000, 1.000000, 0.100000),
	(0.000000, 1.000000, -0.100000),
	(0.000000, 0.800000, -0.100000),
	]
	edges = [
	(0, 1),
	(1, 2),
	(2, 3),
	(3, 4),
	(4, 5),
	(1, 5),
	]
	mesh = bpy.data.meshes.new(widget_name)
	mesh.from_pydata(verts, edges, [])
	mesh.update()
	wgt = bpy.data.objects.new(widget_name, mesh)
	return wgt

def _create_shoulder_widget(widget_name):
	verts = [
		(-0.106097, 1.573313, 0.305284),
		(-0.208116, 1.542366, 0.261631),
		(-0.302138, 1.492110, 0.206400),
		(-0.384549, 1.424478, 0.146260),
		(-0.452182, 1.342067, 0.087877),
		(-0.502437, 1.248045, 0.037920),
		(-0.533385, 1.146025, 0.003056),
		(-0.543834, 1.039929, -0.010047),
		(-0.533385, 0.933832, 0.003056),
		(-0.502437, 0.831812, 0.037920),
		(-0.452182, 0.737791, 0.087877),
		(-0.384549, 0.655380, 0.146260),
		(-0.302138, 0.587747, 0.206400),
		(-0.208116, 0.537491, 0.261631),
		(-0.106097, 0.506544, 0.305284),
		(0.106097, 0.506544, 0.305284),
		(0.208116, 0.537491, 0.261631),
		(0.302138, 0.587747, 0.206400),
		(0.384549, 0.655380, 0.146260),
		(0.452182, 0.737791, 0.087877),
		(0.502437, 0.831812, 0.037920),
		(0.533385, 0.933832, 0.003056),
		(0.543834, 1.039929, -0.010047),
		(0.533385, 1.146025, 0.003056),
		(0.502437, 1.248045, 0.037920),
		(0.452182, 1.342067, 0.087877),
		(0.384549, 1.424478, 0.146260),
		(0.302138, 1.492110, 0.206400),
		(0.208116, 1.542366, 0.261631),
		(0.106097, 1.573313, 0.305284),
		(-0.056901, 1.578159, 0.317065),
		(0.056901, 1.578159, 0.317065),
		(0.000000, 1.580480, 0.322709),
		(-0.056901, 0.501699, 0.317065),
		(0.056901, 0.501699, 0.317065),
		(0.000000, 0.499377, 0.322709),
	]
	edges = [
		(1, 0),
		(2, 1),
		(3, 2),
		(4, 3),
		(5, 4),
		(6, 5),
		(7, 6),
		(8, 7),
		(9, 8),
		(10, 9),
		(11, 10),
		(12, 11),
		(13, 12),
		(14, 13),
		(16, 15),
		(17, 16),
		(18, 17),
		(19, 18),
		(20, 19),
		(21, 20),
		(22, 21),
		(23, 22),
		(24, 23),
		(25, 24),
		(26, 25),
		(27, 26),
		(28, 27),
		(29, 28),
		(30, 32),
		(32, 31),
		(33, 35),
		(35, 34),
		(30, 0),
		(31, 29),
		(33, 14),
		(34, 15),
	]
	mesh = bpy.data.meshes.new(widget_name)
	mesh.from_pydata(verts, edges, [])
	mesh.update()
	wgt = bpy.data.objects.new(widget_name, mesh)
	return wgt

def _create_root_widget(widget_name):
	verts = [
        (0.000000, 1.400895, 0.002833),
        (-0.195090, 0.983559, 0.002833),
        (-0.382683, 0.926653, 0.002833),
        (-0.555570, 0.834243, 0.002833),
        (-0.707107, 0.709880, 0.002833),
        (-0.831470, 0.558344, 0.002833),
        (-0.923880, 0.385457, 0.002833),
        (-0.980785, 0.197864, 0.002833),
        (-1.398121, 0.002773, 0.002833),
        (-0.980785, -0.192317, 0.002833),
        (-0.923880, -0.379910, 0.002833),
        (-0.831470, -0.552797, 0.002833),
        (-0.707107, -0.704333, 0.002833),
        (-0.555570, -0.828696, 0.002833),
        (-0.382683, -0.921106, 0.002833),
        (-0.195090, -0.978012, 0.002833),
        (0.000000, -1.395348, 0.002833),
        (0.195090, -0.978012, 0.002833),
        (0.382683, -0.921106, 0.002833),
        (0.555570, -0.828696, 0.002833),
        (0.707107, -0.704333, 0.002833),
        (0.831470, -0.552797, 0.002833),
        (0.923880, -0.379910, 0.002833),
        (0.980785, -0.192317, 0.002833),
        (1.398121, 0.002773, 0.002833),
        (0.980785, 0.197864, 0.002833),
        (0.923880, 0.385457, 0.002833),
        (0.831470, 0.558344, 0.002833),
        (0.707107, 0.709880, 0.002833),
        (0.555570, 0.834243, 0.002833),
        (0.382683, 0.926653, 0.002833),
        (0.195090, 0.983559, 0.002833),
	]
	edges = [
        (1, 0),
        (2, 1),
        (3, 2),
        (4, 3),
        (5, 4),
        (6, 5),
        (7, 6),
        (8, 7),
        (9, 8),
        (10, 9),
        (11, 10),
        (12, 11),
        (13, 12),
        (14, 13),
        (15, 14),
        (16, 15),
        (17, 16),
        (18, 17),
        (19, 18),
        (20, 19),
        (21, 20),
        (22, 21),
        (23, 22),
        (24, 23),
        (25, 24),
        (26, 25),
        (27, 26),
        (28, 27),
        (29, 28),
        (30, 29),
        (31, 30),
        (0, 31),
	]	
	mesh = bpy.data.meshes.new(widget_name)
	mesh.from_pydata(verts, edges, [])
	mesh.update()
	wgt = bpy.data.objects.new(widget_name, mesh)
	return wgt

def _create_gear_widget(widget_name):
	verts = [
        (0.000000, 0.502774, 0.002833),
        (-0.050327, 0.385050, 0.002833),
        (-0.099794, 0.375211, 0.002833),
        (-0.191342, 0.464713, 0.002833),
        (-0.250000, 0.435786, 0.002833),
        (-0.234723, 0.308671, 0.002833),
        (-0.272643, 0.275416, 0.002833),
        (-0.396677, 0.307154, 0.002833),
        (-0.433012, 0.252773, 0.002833),
        (-0.356225, 0.150327, 0.002833),
        (-0.372437, 0.102568, 0.002833),
        (-0.495723, 0.068037, 0.002833),
        (-0.500000, 0.002773, 0.002833),
        (-0.382277, -0.047554, 0.002833),
        (-0.372437, -0.097021, 0.002833),
        (-0.461940, -0.188568, 0.002833),
        (-0.433012, -0.247227, 0.002833),
        (-0.305898, -0.231950, 0.002833),
        (-0.272643, -0.269870, 0.002833),
        (-0.304381, -0.393903, 0.002833),
        (-0.250000, -0.430239, 0.002833),
        (-0.147554, -0.353452, 0.002833),
        (-0.099794, -0.369664, 0.002833),
        (-0.065263, -0.492949, 0.002833),
        (0.000000, -0.497227, 0.002833),
        (0.050327, -0.379503, 0.002833),
        (0.099794, -0.369664, 0.002833),
        (0.191342, -0.459166, 0.002833),
        (0.250000, -0.430239, 0.002833),
        (0.234723, -0.303124, 0.002833),
        (0.272643, -0.269870, 0.002833),
        (0.396677, -0.301607, 0.002833),
        (0.433012, -0.247227, 0.002833),
        (0.356225, -0.144780, 0.002833),
        (0.372437, -0.097021, 0.002833),
        (0.495723, -0.062490, 0.002833),
        (0.500000, 0.002773, 0.002833),
        (0.382277, 0.053101, 0.002833),
        (0.372437, 0.102568, 0.002833),
        (0.461940, 0.194115, 0.002833),
        (0.433012, 0.252773, 0.002833),
        (0.305898, 0.237497, 0.002833),
        (0.272643, 0.275416, 0.002833),
        (0.304381, 0.399450, 0.002833),
        (0.250000, 0.435786, 0.002833),
        (0.147554, 0.358999, 0.002833),
        (0.099794, 0.375211, 0.002833),
        (0.065263, 0.498496, 0.002833),
        (0.000000, 0.252773, 0.002833),
        (-0.064705, 0.244255, 0.002833),
        (-0.125000, 0.219280, 0.002833),
        (-0.176776, 0.179550, 0.002833),
        (-0.216506, 0.127773, 0.002833),
        (-0.241481, 0.067478, 0.002833),
        (-0.250000, 0.002773, 0.002833),
        (-0.241481, -0.061931, 0.002833),
        (-0.216506, -0.122227, 0.002833),
        (-0.176776, -0.174003, 0.002833),
        (-0.125000, -0.213733, 0.002833),
        (-0.064705, -0.238708, 0.002833),
        (0.000000, -0.247227, 0.002833),
        (0.064705, -0.238708, 0.002833),
        (0.125000, -0.213733, 0.002833),
        (0.176776, -0.174003, 0.002833),
        (0.216506, -0.122227, 0.002833),
        (0.241481, -0.061931, 0.002833),
        (0.250000, 0.002773, 0.002833),
        (0.241481, 0.067478, 0.002833),
        (0.216506, 0.127773, 0.002833),
        (0.176776, 0.179550, 0.002833),
        (0.125000, 0.219280, 0.002833),
        (0.064705, 0.244255, 0.002833),
	]
	edges = [
        (1, 0),
        (2, 1),
        (3, 2),
        (4, 3),
        (5, 4),
        (6, 5),
        (7, 6),
        (8, 7),
        (9, 8),
        (10, 9),
        (11, 10),
        (12, 11),
        (13, 12),
        (14, 13),
        (15, 14),
        (16, 15),
        (17, 16),
        (18, 17),
        (19, 18),
        (20, 19),
        (21, 20),
        (22, 21),
        (23, 22),
        (24, 23),
        (25, 24),
        (26, 25),
        (27, 26),
        (28, 27),
        (29, 28),
        (30, 29),
        (31, 30),
        (32, 31),
        (33, 32),
        (34, 33),
        (35, 34),
        (36, 35),
        (37, 36),
        (38, 37),
        (39, 38),
        (40, 39),
        (41, 40),
        (42, 41),
        (43, 42),
        (44, 43),
        (45, 44),
        (46, 45),
        (47, 46),
        (0, 47),
        (49, 48),
        (50, 49),
        (51, 50),
        (52, 51),
        (53, 52),
        (54, 53),
        (55, 54),
        (56, 55),
        (57, 56),
        (58, 57),
        (59, 58),
        (60, 59),
        (61, 60),
        (62, 61),
        (63, 62),
        (64, 63),
        (65, 64),
        (66, 65),
        (67, 66),
        (68, 67),
        (69, 68),
        (70, 69),
        (71, 70),
        (48, 71),
	]
	mesh = bpy.data.meshes.new(widget_name)
	mesh.from_pydata(verts, edges, [])
	mesh.update()
	wgt = bpy.data.objects.new(widget_name, mesh)
	return wgt

"""
import bpy

obj = bpy.context.object
mesh = obj.data

# Apply object scale/rotation into verts so the dump matches what you see
mesh.transform(obj.matrix_world)
obj.matrix_world.identity()
mesh.update()

print("verts = [")
for v in mesh.vertices:
    print(f"\t({v.co.x:.6f}, {v.co.y:.6f}, {v.co.z:.6f}),")
print("]")

print("edges = [")
for e in mesh.edges:
    print(f"\t({e.vertices[0]}, {e.vertices[1]}),")
print("]")
"""