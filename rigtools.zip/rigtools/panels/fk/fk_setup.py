import bpy
from bpy.props import (
	StringProperty,
	BoolProperty,
	EnumProperty,
	FloatProperty,
	IntProperty,
)

from rigtools.assemblies.reconfigure_assembly import prepare_rebuild
from rigtools.assemblies.assembly_transaction import AssemblyTransactionError, run_assembly_transaction
from rigtools.utils.profiling import profile
from rigtools.assemblies.assembly_data import find_assembly
from rigtools.assemblies.fk_assembly import FKAssemblyOptions, create_fk_assembly
from rigtools.assemblies.fk_templates import get_fk_template, validate_fk_templates
from rigtools.assemblies.template_options import resolve_template_options
from rigtools.panels.assembly_setup import begin_setup_edit, validate_setup_context
from rigtools.panels.skirt_legs import draw_skirt_legs, fill_skirt_legs, iter_skirt_leg_slots
from rigtools.panels.template_draw import SplitSection, TemplateDraw
from rigtools.utils.skirt_legs import FORWARD_AXIS_ITEMS, scan_leg_assemblies
from rigtools.tool.skirt_ride import SkirtLeg
from rigtools.utils.bone import select_bones
from rigtools.utils.naming import bone_template, guess_limb_name
from rigtools.utils.bone_chain import ChainBranchingError, find_chains_from_selection
from rigtools.utils.widget import fk_widget_types, master_widget_types

class RIG_OT_advanced_fk_tweak_setup(bpy.types.Operator):
	"""Setup FK/Tweak assembly"""
	bl_idname = "rig.advanced_fk_setup"
	bl_label = "Generate FK Assembly"
	bl_options = {'REGISTER', 'UNDO'}

	limb_property_base_name: StringProperty(
		name="Limb Name",
		description="Base name of the property to store the limb. Example: 'arm', 'leg', 'tail', etc.",
		default=""
	)

	control_mode: EnumProperty(
		name="Control Mode",
		description="Control mode for the FK/Tweak chain",
		items=[
			('FK/TWEAK', 'FK/TWEAK', 'Create an FK/Tweak chain'),
			('FK', 'FK only', 'Create an simple FK chain without tweak bones'),
			('TWEAK', 'TWEAK only', 'Create a tweak only chain. Tweak bones should be re-parented later.'),
		],
		default='FK/TWEAK'
	)

	add_tweak_bones: BoolProperty(
		name="Add Tweak Bones",
		description="Add tweak bones to the chain",
		default=True
	)

	skip_first_tweak: BoolProperty(
		name="Skip First Tweak",
		description="Skip the first tweak bone",
		default=False
	)

	fk_widget: EnumProperty(
		name="FK Widget",
		description="Create widgets for the FK bones",
		items=fk_widget_types,
		default='CIRCLE'
	)

	add_rotation_isolation: BoolProperty(
		name="Add Rotation Isolation",
		description="Add rotation isolation to the FK bones.",
		default=False
	)

	create_master_controllers: BoolProperty(
		name="Create FK Master Controllers / FK Follow",
		description="Create master controllers along the FK chain.",
		default=True
	)

	master_controllers_spacing: EnumProperty(
		name="Master Controllers Spacing",
		description="Spacing of the master controllers.",
		items=[
			('SINGLE', 'Single Controller', 'Use a single master controller'),
			('INTERVAL', 'Interval', 'Use an interval between master controllers'),
		],
		default='SINGLE'
	)

	master_controllers_interval: IntProperty(
		name="Interval",
		description="Number of bones to skip before creating a master controller.",
		options={'HIDDEN'}
	)

	master_controllers_interval_UI: IntProperty(
		name="Interval",
		description="Number of bones to skip before creating a master controller.",
		default=3,
		min=2,
	)

	master_controllers_skip_first: BoolProperty(
		name="Skip First",
		description="Skip the first bone when creating master controllers.",
		default=False
	)

	master_controllers_type: EnumProperty(
		name="Type",
		description="Type of master controller to create.",
		items=[
			('FK', 'Use FK Bones', 'Use the existing FK bones as master controllers (FK follow)'),
			('MASTER', 'Add Dedicated Masters', 'Create dedicated master controllers'),
		],
		default='FK'
	)

	master_controllers_widget: EnumProperty(
		name="Master Controller Widget",
		description="Type of widget to create for the master controllers.",
		items=master_widget_types,
		default='CIRCLE'
	)

	fk_collection_name: StringProperty(
		name="FK Collection Name",
		description="Name of the collection to store the FK bones, or blank to copy collection from selected bones",
		default=""
	)

	tweak_collection_name: StringProperty(
		name="Tweak Collection Name",
		description="Name of the collection to store the tweak bones, or blank to copy collection from selected bones",
		default=""
	)

	tweak_relationship: EnumProperty(
		name="Tweak Relationship",
		description="Type of relationship for the tweak bones",
		items=[
			('STRETCH_TO', 'Stretch To', 'Stretch the tweak bone to the target bone'),
			('DAMPED_TRACK', 'Damped Track', 'Damped track the tweak bone to the target bone'),
		],
		default='STRETCH_TO'
	)

	assembly_uid: StringProperty(
		name="Assembly UID",
		description="UID of the assembly to use for the FK/Tweak chain",
		default="",
		options={'HIDDEN', 'SKIP_SAVE'}
	)

	assembly_uids: StringProperty(
		name="Assembly UIDs",
		description="Comma-separated UIDs for multi-reconfigure; empty = single assembly_uid",
		default="",
		options={'HIDDEN', 'SKIP_SAVE'}
	)

	template_id: StringProperty(
		name="Template ID",
		description="FK template to apply on invoke",
		default="",
		options={'HIDDEN'}
	)

	template_name: StringProperty(
		name="Template Name",
		description="Name of the template to use for the FK/Tweak chain",
		default="",
		options={'HIDDEN'}
	)

	add_skirt_collision: BoolProperty(
		name="Add Skirt Collision",
		description="Add skirt collision to the FK bones.",
		default=False
	)

	add_skirt_ride: BoolProperty(
		name="Add Skirt Ride",
		description="Short skirts typically ride up when the leg is lifted.",
		default=False
	)

	add_finger_curl: BoolProperty(
		name="Add Finger Curl",
		description="Add finger curl to the FK bones.",
		default=False
	)

	finger_curl_axis: EnumProperty(
		name="Finger Curl Axis",
		description="Axis for the finger curl.",
		items=[
			('AUTO', 'Auto', 'Auto detect axis for curl'),
			('X', 'X', 'Use +X axis for curl'),
			('-X', '-X', 'Use -X axis for curl'),
			('Z', 'Z', 'Use +Z axis for curl'),
			('-Z', '-Z', 'Use -Z axis for curl'),
		],
		default='AUTO'
	)

	normalize_fk_widget_scale: BoolProperty(
		name="Normalize FK Widget Scale",
		description="Size every FK widget to the chain's average bone length.",
		default=False
	)

	taper_fk_widgets: BoolProperty(
		name="Taper FK Widgets",
		description="Shrink normalized FK widgets toward the tip.",
		default=False
	)

	fk_widget_scale: FloatProperty(
		name="FK Widget Scale",
		description="Multiplier on the size of every FK widget.",
		default=1.0,
		min=0.01,
	)

	create_shoulder_vis: BoolProperty(
		name="Create Shoulder Vis",
		description="Create a shoulder visibility control.",
		default=False,
		options={'HIDDEN'},
	)

	share_fk_ik_role: BoolProperty(
		name="Share FK/IK Role",
		description="Share the same role for FK and IK bones.",
		default=False,
		options={'HIDDEN'},
	)

	assembly_name_base: StringProperty(
		name="Assembly Name Base",
		description="Base name for the assembly; limb name is used when blank.",
		default="",
		options={'HIDDEN'},
	)

	@classmethod
	def description(cls, context, properties):
		if properties.template_id:
			template = get_fk_template(properties.template_id)
			if template:
				return template.description
		return "Setup FK/Tweak assembly"

	##################################################################################################
	# invoke

	def _invoke_from_template(self, context):
		template = get_fk_template(self.template_id)
		if not template:
			self.report({'ERROR'}, f"Unknown FK template: '{self.template_id}'")
			return {'CANCELLED'}

		option_values = resolve_template_options(FKAssemblyOptions, template.options)
		for key, value in option_values.items():
			setattr(self, key, value)

		if not self.limb_property_base_name:
			try:
				chains = find_chains_from_selection(context)
			except ChainBranchingError as error:
				self.report({'ERROR'}, str(error))
				return {'CANCELLED'}

			if not chains:
				self.report({'ERROR'}, "No chains selected.")
				return {'CANCELLED'}

			self.limb_property_base_name = guess_limb_name(chains[0][0])

		self.template_name = template.label

	def _invoke_from_assembly(self, context):
		assembly = find_assembly(context.object, self.assembly_uid)
		if not assembly:
			self.report({'ERROR'}, "Assembly not found.")
			return {'CANCELLED'}
		
		options = assembly.get_options()
		for key, value in options.items():
			if not hasattr(self, key):
				continue
			setattr(self, key, value)

		self.template_name = assembly.template_name
		self.template_id = assembly.template_id

	def invoke(self, context, event):
		show_dialog = True

		if self.assembly_uid:
			result = self._invoke_from_assembly(context)
		else:
			result = self._invoke_from_template(context)
			template = get_fk_template(self.template_id)
			if template:
				show_dialog = template.show_dialog

		if result == {'CANCELLED'}:
			return result

		self.add_tweak_bones = (self.control_mode != 'FK')
		self.master_controllers_spacing = 'SINGLE' if self.master_controllers_interval <= 1 else 'INTERVAL'
		self.master_controllers_interval_UI = self.master_controllers_interval if self.master_controllers_interval >= 2 else 3
		fill_skirt_legs(context)

		if show_dialog:
			return context.window_manager.invoke_props_dialog(self, width=350)
		return self.execute(context)

	##################################################################################################
	# draw

	def draw(self, context):
		layout = self.layout
		template = get_fk_template(self.template_id)
		split_size = 0.6

		def field_visible(field_name):
			if field_name in ["tweak_relationship", "skip_first_tweak"]:
				return self.control_mode != 'FK' and (self.add_tweak_bones or self.control_mode == 'TWEAK')
			if field_name in ["fk_widget"]:
				return self.control_mode != 'TWEAK'
			if field_name in ["normalize_fk_widget_scale", "taper_fk_widgets"]:
				return self.control_mode != 'TWEAK' and self.fk_widget != 'NONE'
			if field_name in ["add_tweak_bones"]:
				control_mode_visible = "control_mode" in template.redo_fields
				return self.control_mode != 'TWEAK' and not control_mode_visible
			if field_name in ["add_rotation_isolation", "create_rotation_follow_setup"]:
				return self.control_mode != 'TWEAK'
			if field_name in ["rotation_follow_skip", "rotation_follow_relationship"]:
				return self.create_rotation_follow_setup
			if field_name in ["skirt_legs"]:
				return self.add_skirt_collision or self.add_skirt_ride
			if field_name in ["create_master_controllers"]:
				return self.control_mode != 'TWEAK'
			if field_name in ["master_controllers_spacing", "master_controllers_skip_first", "master_controllers_type"]:
				return self.control_mode != 'TWEAK' and self.create_master_controllers
			if field_name in ["master_controllers_interval_UI"]:
				return self.control_mode != 'TWEAK' and self.create_master_controllers and self.master_controllers_spacing == 'INTERVAL'
			if field_name in ["master_controllers_widget"]:
				return self.control_mode != 'TWEAK' and self.create_master_controllers and self.master_controllers_type == 'MASTER'
			if field_name in ["add_finger_curl"]:
				return self.control_mode != 'TWEAK'
			if field_name in ["finger_curl_axis"]:
				return self.add_finger_curl
			return True

		draw = TemplateDraw(self, template, split_size=split_size, visible_func=field_visible, 
			related_fields={
				"master_controllers_spacing": "master_controllers_interval",
				"master_controllers_interval_UI": "master_controllers_interval",
			}
		)

		draw.box_section(layout, ["limb_property_base_name", "control_mode", "fk_widget", "fk_widget_scale", "normalize_fk_widget_scale", "taper_fk_widgets", "add_tweak_bones", "tweak_relationship", "skip_first_tweak"],
			"FK Chain Settings:", "SETTINGS", lambda col: (

			draw.draw_section(col, ["limb_property_base_name", "control_mode", "fk_widget", "fk_widget_scale", "normalize_fk_widget_scale", "taper_fk_widgets"], lambda: (
				draw.split_field(col, "Limb Name:", "limb_property_base_name"),
				draw.split_field(col, "Control Mode:", "control_mode"),
				draw.split_field(col, "FK Widget:", "fk_widget"),
				draw.split_field(col, "FK Widget Scale:", "fk_widget_scale"),
				draw.split_row(col, [
					SplitSection(label="Normalize Widget Scale", prop="normalize_fk_widget_scale"),
					SplitSection(label="Taper", prop="taper_fk_widgets", enabled=self.normalize_fk_widget_scale),
				], align_to_split=True),
			)),
			draw.draw_section(col, ["add_tweak_bones", "tweak_relationship", "skip_first_tweak"], lambda: (
				draw.full_field(col, "Add Tweak Bones", "add_tweak_bones"),
				draw.split_field(col, "Tweak Relationship:", "tweak_relationship"),
				draw.full_field(col, "Skip First Tweak", "skip_first_tweak"),
			)),
		))
		draw.draw_section(layout, ["create_master_controllers"], lambda: (
			draw.full_field(layout, "Create FK Master Controllers / FK Follow", "create_master_controllers"),
			draw.box_section(layout, ["master_controllers_spacing", "master_controllers_interval_UI", "master_controllers_skip_first", "master_controllers_type"], 
				"", "NONE", lambda col: (
		
				draw.draw_section(col, ["master_controllers_type", "master_controllers_spacing", "master_controllers_interval_UI", "master_controllers_skip_first"], lambda: (
					draw.expand_field(col, "master_controllers_type"),
					draw.expand_field(col, "master_controllers_spacing"),
					draw.full_field(col, "Interval", "master_controllers_interval_UI"),
					draw.full_field(col, "Skip First", "master_controllers_skip_first"),
				)),
				draw.draw_section(col, ["master_controllers_widget"], lambda: (
					draw.split_field(col, "Master Controller Widget:", "master_controllers_widget"),
				)),
			))
		))
		draw.draw_section(layout, ["add_finger_curl", "finger_curl_axis"], lambda: (
			draw.full_field(layout, "Add Finger Curl", "add_finger_curl"),
			draw.split_field(layout, "Finger Curl Axis:", "finger_curl_axis", expand=True, split_size=0.4),
		))

		draw.draw_section(layout, ["add_skirt_collision", "add_skirt_ride", "skirt_legs"], lambda: (
			draw.full_field(layout, "Add Skirt Collision", "add_skirt_collision"),
			draw.full_field(layout, "Add Skirt Ride", "add_skirt_ride"),
			draw.box_section(layout, ["skirt_legs"], "", "NONE", lambda col: (
				draw_skirt_legs(context, col, show_axis=self.add_skirt_ride),
			)),
		))
		
	##################################################################################################
	# execute

	def validate_chains(self, context, chains):
		if not chains:
			return "No chains selected."
		return None

	def execute(self, context):
		if not self.limb_property_base_name:
			self.report({'ERROR'}, "Limb name is required.")
			self.assembly_uid = ""
			return {'CANCELLED'}

		skirt_slots = list(iter_skirt_leg_slots(context))
		if (self.add_skirt_collision or self.add_skirt_ride) and not skirt_slots:
			self.report({'ERROR'}, "No skirt legs specified. Add leg assemblies or pick thigh bones.")
			self.assembly_uid = ""
			return {'CANCELLED'}

		err = validate_setup_context(
			context,
			check_property_bone=self.add_rotation_isolation or self.add_skirt_collision or self.add_skirt_ride,
		)
		if err:
			self.report({'ERROR'}, err)
			self.assembly_uid = ""
			return {'CANCELLED'}

		if self.control_mode != 'TWEAK':
			self.control_mode = 'FK/TWEAK' if self.add_tweak_bones else 'FK'

		interval = 0 if self.master_controllers_spacing == 'SINGLE' else self.master_controllers_interval_UI
		options = FKAssemblyOptions(
			limb_property_base_name=self.limb_property_base_name.strip().lower(),
			assembly_name_base=self.assembly_name_base.strip().lower(),
			control_mode=self.control_mode,
			fk_bone_template=bone_template('fk'),
			skip_first_tweak=self.skip_first_tweak,
			fk_widget=self.fk_widget,
			create_master_controllers=self.create_master_controllers,
			master_controllers_interval=interval,
			master_controllers_skip_first=self.master_controllers_skip_first,
			master_controllers_type=self.master_controllers_type,
			master_controllers_widget=self.master_controllers_widget,
			tweak_relationship=self.tweak_relationship,
			add_rotation_isolation=self.add_rotation_isolation,
			add_skirt_collision=self.add_skirt_collision,
			skirt_collision_target_bone_names=[slot.thigh for slot in skirt_slots],
			add_skirt_ride=self.add_skirt_ride,
			skirt_ride_legs=[
				SkirtLeg(bone_name=slot.thigh, forward_axis=slot.forward_axis)
				for slot in skirt_slots
			],
			add_finger_curl=self.add_finger_curl,
			finger_curl_axis=self.finger_curl_axis,
			normalize_fk_widget_scale=self.normalize_fk_widget_scale,
			taper_fk_widgets=self.taper_fk_widgets,
			fk_widget_scale=self.fk_widget_scale,
			create_shoulder_vis=self.create_shoulder_vis,
			share_fk_ik_role=self.share_fk_ik_role,
		)

		prev_state = begin_setup_edit(context)

		assembly_uids = [u for u in self.assembly_uids.split(',') if u] or [self.assembly_uid]
		if self.assembly_uid or len(assembly_uids) > 1:
			rebuild_chains = {uid: find_assembly(context.object, uid).get_chain() for uid in assembly_uids}
			chains = list(rebuild_chains.values())
		else:
			rebuild_chains = {}
			try:
				chains = find_chains_from_selection(context)
			except Exception as e:
				self.report({'ERROR'}, str(e))
				self.assembly_uid = ""
				prev_state.restore(context)
				return {'CANCELLED'}

		err = self.validate_chains(context, chains)
		if err:
			self.report({'ERROR'}, err)
			self.assembly_uid = ""
			prev_state.restore(context)
			return {'CANCELLED'}

		def create(uids, chains, prior_configs):
			return create_fk_assembly(
				context,
				chains,
				self.template_id,
				self.template_name,
				options,
				replacement_uids=uids,
				prior_configs=prior_configs,
			)

		def build():
			if len(rebuild_chains) > 0:
				prior_configs = prepare_rebuild(context, assembly_uids)
				return create(assembly_uids, [rebuild_chains[uid] for uid in assembly_uids], prior_configs)
			else:
				return create(None, chains, {})

		try:
			with profile():
				fk_controls = run_assembly_transaction(build)
		except AssemblyTransactionError as e:
			self.report({'ERROR'}, str(e))
			prev_state.restore(context)
			return {'CANCELLED'}

		if fk_controls:
			if context.object.mode != 'POSE':
				bpy.ops.object.mode_set(mode='POSE')
			select_bones(context.object, fk_controls, deselect=True)

		chain_count = len(chains)
		self.report({'INFO'}, f"Successfully generated {chain_count} FK/Tweak chain{'s' if chain_count != 1 else ''}.")
		prev_state.restore_mirror(context)
		return {'FINISHED'}


classes = (
	RIG_OT_advanced_fk_tweak_setup,
)

def register():
	validate_fk_templates()
	for cls in classes:
		bpy.utils.register_class(cls)

def unregister():
	for cls in reversed(classes):
		bpy.utils.unregister_class(cls)

if __name__ == "__main__":
	try:
		unregister()
	except Exception:
		pass
	register()

	bpy.ops.rig.advanced_fk_setup('INVOKE_DEFAULT')
