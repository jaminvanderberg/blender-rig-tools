bl_info = {
	"name": "Rig Tools",
	"author": "Jamin VanderBerg",
	"version": (0, 90),
	"blender": (4, 1, 0),
	"location": "View3D > Sidebar > Rig Tools",
	"description": "Helper functions for rig building",
	"category": "Rigging"
}

import bpy

from rigtools import generate_org_bones
from rigtools import panel
from rigtools import fk_tweak_chain
from rigtools import selection_panel
from rigtools import batch_rename
from rigtools import create_mch_bones
from rigtools import create_rotation_isolation
from rigtools import preferences
from rigtools import preferences_io
from rigtools import armature_settings
from rigtools import rename_chain
from rigtools import parent_along_chain
from rigtools import find_dependents
from rigtools import weight_paint_proxy
from rigtools.panels.ik import ik_panel
from rigtools.rig_ui import collections_panel
from rigtools.rig_ui import property_panel
from rigtools.rig_ui import visibility_panel
from rigtools.rig_ui import snapping_panel

classes = (
	preferences.RigToolsPreferences,
	preferences_io.RIG_OT_export_preferences,
	preferences_io.RIG_OT_import_preferences,
	panel.RIG_PT_tools_npanel,
	generate_org_bones.RIG_OT_generate_org_bones,
	fk_tweak_chain.RIG_OT_create_fk_tweak_chain,
	batch_rename.RIG_OT_batch_rename_bones,
	create_mch_bones.RIG_OT_create_mch_bones,
	create_mch_bones.RIG_PT_create_mch_bones,
	create_rotation_isolation.RIG_OT_create_rotation_isolation,
	parent_along_chain.RIG_OT_parent_along_chain,
)

addon_keymaps = []

def register():

	armature_settings.register()
	selection_panel.register()
	ik_panel.register()
	rename_chain.register()
	find_dependents.register()
	weight_paint_proxy.register()
	collections_panel.register()
	property_panel.register()
	visibility_panel.register()
	snapping_panel.register()

	for cls in classes:
		bpy.utils.register_class(cls)

	# Scene properties
	bpy.types.Scene.mch_bone_name = bpy.props.StringProperty(
		name="Bone Name", 
		description="Template using {name} as a placeholder (e.g., 'MCH-{name}' or '{name}_MCH'). L/R suffixes will be preserved.",
		default="MCH-{name}"
	)

	# Keymaps
	wm = bpy.context.window_manager
	kc = wm.keyconfigs.addon
	if kc:
		# Armature Edit keymap
		km = kc.keymaps.new(name='Armature', space_type='EMPTY')
		kmi = km.keymap_items.new(
			"rig.batch_rename_bones", 
			type='F2', 
			value='PRESS', 
			ctrl=True
		)
		addon_keymaps.append((km, kmi))

		# Pose mode keymap
		km_pose = kc.keymaps.new(name='Pose', space_type='EMPTY')
		kmi_pose = km_pose.keymap_items.new(
			"rig.batch_rename_bones", 
			type='F2', 
			value='PRESS', 
			ctrl=True
		)
		addon_keymaps.append((km_pose, kmi_pose))        

def unregister():
	for km, kmi in addon_keymaps:
		km.keymap_items.remove(kmi)
	addon_keymaps.clear()

	del bpy.types.Scene.mch_bone_name
	
	for cls in reversed(classes):
		bpy.utils.unregister_class(cls)

	collections_panel.unregister()
	property_panel.unregister()
	find_dependents.unregister()
	weight_paint_proxy.unregister()
	rename_chain.unregister()
	selection_panel.unregister()
	armature_settings.unregister()
	ik_panel.unregister()
	visibility_panel.unregister()
	snapping_panel.unregister()

if __name__ == "__main__":
	register()
