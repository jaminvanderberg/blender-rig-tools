import bpy
from rigtools.assemblies.tool_data.mechanism_bones import MechanismBones
from rigtools.utils.bone import duplicate_bone
from rigtools.utils.naming import name_bone
from rigtools.preferences import get_preferences
from rigtools.utils.widget import IK_WIRE_WIDTH

spline_twist_type = [
	('NONE', "None", "No twist controllers"),
	('START_END', "Start and End", "Twist controllers at the start and end of the spline"),
	('START', "Start", "Twist controller at the start of the spline"),
	('END', "End", "Twist controller at the end of the spline"),
	('ALL', "All", "Twist controllers at every control point of the spline"),
]

class SplineIK:
	def __init__(self, *,
		control_count: int = 3,
		skip_first: bool = False,
		twist_type: str = 'START_END',
	):
		self.control_count = control_count
		self.skip_first = skip_first
		self.twist_type = twist_type

		self.mch_bone_names = None
		self.control_names = None
		self.spline_object = None
		self.twist_names = None

		self.mechanism_bones = MechanismBones()
		self.property_names = []
		self.object_names = []

	def edit_mode(self, context, mch_bone_names, name_source=None):
		self.mch_bone_names = mch_bone_names

		obj = context.object
		edit_bones = obj.data.edit_bones

		if obj.mode != 'EDIT':
			bpy.ops.object.mode_set(mode='EDIT')

		bones = mch_bone_names[1 if self.skip_first else 0:]

		chain_parent = edit_bones[mch_bone_names[0]].parent

		spline_length = sum(edit_bones[name].length for name in bones) / len(bones) * 0.5

		points = [edit_bones[b].head for b in bones] + [edit_bones[bones[-1]].tail]
		
		self.control_names = []
		self.twist_names = []
		bone_suffix = "abcdefghijklmnopqrstuvwxyz"
		bone_count = len(bones)
		for i in range(self.control_count):
			chain_pos = (i / (self.control_count - 1)) * bone_count
			joint_index = round(chain_pos)

			if chain_pos >= bone_count:
				seg_index = bone_count - 1
				seg_t = 1.0
			else:
				seg_index = int(chain_pos)
				seg_t = chain_pos - seg_index
			
			pos = points[seg_index].lerp(points[seg_index + 1], seg_t)
			direction = (points[seg_index + 1] - points[seg_index]).normalized()

			if i == 0:
				pos_name = "start"
			elif i == self.control_count - 1:
				pos_name = "end"
			elif i == 1 and self.control_count == 3:
				pos_name = "mid"
			else:
				pos_name = "mid." + bone_suffix[(i - 1) % len(bone_suffix)]

			source = name_source[0] if name_source else edit_bones[bones[seg_index]].name
			ref_bone = edit_bones[bones[seg_index]]
			spline_bone_name = name_bone("ik_spline", source, i=pos_name, strip_numbers=True)
			spline_bone = edit_bones.new(spline_bone_name)
			spline_bone.head = pos
			direction = (points[seg_index + 1] - points[seg_index]).normalized()
			spline_bone.tail = pos + direction * spline_length
			spline_bone.parent = chain_parent
			spline_bone.roll = ref_bone.roll
			
			# Twist controllers
			do_twist = False
			if self.twist_type == 'ALL':
				do_twist = True
			elif i == 0 and self.twist_type in ['START', 'START_END']:
				do_twist = True
			elif i == self.control_count - 1 and self.twist_type in ['END', 'START_END']:
				do_twist = True

			twist_bone = None
			if do_twist:
				twist_name = name_bone("ik_spline_twist", source, i=pos_name)
				twist_bone = duplicate_bone(obj.data, spline_bone, twist_name, 1.2)
				self.twist_names.append(twist_bone.name)
				style = self.mechanism_bones.add(twist_bone.name, 'ik')
				style.set(widget='TWIST', wire_width=IK_WIRE_WIDTH)
				twist_bone.parent = spline_bone

			self.control_names.append(spline_bone.name)
			style = self.mechanism_bones.add(spline_bone.name, 'ik')
			style.set(widget='SPHERE', wire_width=IK_WIRE_WIDTH)

		if self.twist_names and self.twist_type in ['START', 'START_END', 'ALL']:
			first = edit_bones[self.twist_names[0]]
			mch = edit_bones[bones[0]]
			mch.parent = first

		return self

	def object_mode(self, context):
		obj = context.object
		
		if obj.mode != 'OBJECT':
			bpy.ops.object.mode_set(mode='OBJECT')

		armature_data = obj.data
		prev_pose_position = armature_data.pose_position
		armature_data.pose_position = 'REST'	

		# Create the spline object
		spline_name = name_bone("spline_object", self.control_names[0])
		curve_data = bpy.data.curves.new(spline_name, 'CURVE')
		curve_data.dimensions = '3D'
		curve_obj = bpy.data.objects.new(spline_name, curve_data)

		for coll in obj.users_collection:
			coll.objects.link(curve_obj)

		self.spline_object = curve_obj
		self.object_names.append(curve_obj.name)
		curve_obj.parent = obj
		curve_obj.matrix_parent_inverse.identity()
		curve_obj.location = (0.0, 0.0, 0.0)
		curve_obj.rotation_euler = (0.0, 0.0, 0.0)
		curve_obj.scale = (1.0, 1.0, 1.0)

		curve_obj.hide_set(True)
		curve_obj.hide_render = True
		curve_obj["rigtools_helper"] = True

		spline = curve_data.splines.new('BEZIER')
		spline.bezier_points.add(len(self.control_names) - 1)

		handle_size = 0.01

		for i, control_name in enumerate(self.control_names):
			bp = spline.bezier_points[i]
			co = obj.data.bones[control_name].head_local.copy()
			bp.co = co

			if i == 0:
				next = obj.data.bones[self.control_names[i + 1]].head_local.copy()
				direction = (next - co).normalized()
				bp.handle_left_type = bp.handle_right_type = 'ALIGNED'
				bp.handle_right = co + direction * handle_size
				bp.handle_left = co - direction * handle_size
			elif i == len(self.control_names) - 1:
				prev = obj.data.bones[self.control_names[i - 1]].head_local.copy()
				direction = (co - prev).normalized()
				bp.handle_left_type = bp.handle_right_type = 'ALIGNED'
				bp.handle_left = co - direction * handle_size
				bp.handle_right = co + direction * handle_size
			else:
				bp.handle_left = bp.handle_right = co.copy()
				bp.handle_left_type = bp.handle_right_type = 'AUTO'

			mod = curve_obj.modifiers.new(name=f"Hook {control_name}", type='HOOK')
			mod.object = obj
			mod.subtarget = control_name
			mod.center = co
			mod.vertex_indices_set([i * 3, i * 3 + 1, i * 3 + 2])

		armature_data.pose_position = prev_pose_position

		return self

	def pose_mode(self, context):
		obj = context.object
		prefs = get_preferences()

		if obj.mode != 'POSE':
			bpy.ops.object.mode_set(mode='POSE')

		pose_bones = obj.pose.bones

		# Spline IK
		last_mch_bone_name = self.mch_bone_names[-1]
		last_mch_bone = pose_bones[last_mch_bone_name]
		spline_constraint = last_mch_bone.constraints.new('SPLINE_IK')
		spline_constraint.target = self.spline_object
		spline_constraint.chain_count = len(self.mch_bone_names) - 1 if self.skip_first else len(self.mch_bone_names)
		spline_constraint.xz_scale_mode = 'BONE_ORIGINAL'

		ik_names = self.mch_bone_names[1 if self.skip_first else 0:]

		# Twist
		names = self.twist_names or []

		if len(names) >= 2:
			bone_count = len(ik_names)
			denom = len(names) - 1

			# list of (twist_index, n_seg)
			influence = {b: [] for b in range(bone_count)}

			for k in range(len(names) - 1):
				start = int((k / denom) * bone_count)
				mid = int(((k + 1) / denom) * bone_count)
				end = int(((k + 2) / denom) * bone_count)

				twist = k + 1

				for b in range(start, mid + 1):
					if b < bone_count:
						influence[b].append((twist, mid - start + 1))
				for b in range(mid + 1, end + 1):
					if b < bone_count:
						influence[b].append((twist, -(end - mid + 1)))

			## DEBUG OUTPUT ###############################################################
			print(f"twist influences ({bone_count} bones, {len(names)} twists):")
			for b, contribs in influence.items():
				if not contribs:
					print(f"  {ik_names[b]}: (none)")
					continue
				parts = []
				for twist_index, n_seg in contribs:
					sign = '+' if n_seg > 0 else '-'
					parts.append(f"{sign}{names[twist_index]}/{abs(n_seg)}")
				print(f"  [{b}] {ik_names[b]}: {' '.join(parts)}")	
			################################################################################				

			for b in range(bone_count):
				contribs = influence[b]
				if len(contribs) == 0:
					continue

				pb = pose_bones[ik_names[b]]

				pb.rotation_mode = 'XYZ'
				fcurve = pb.driver_add('rotation_euler', 1)
				driver = fcurve.driver
				driver.type = 'SCRIPTED'

				expr = ''
				first = True

				for twist_index, n_seg in contribs:
					var = driver.variables.new()
					var.name = 't' + str(twist_index)
					var.type = 'TRANSFORMS'
					t = var.targets[0]
					t.id = obj
					t.bone_target = names[twist_index]
					t.transform_type = 'ROT_Y'
					t.transform_space = 'LOCAL_SPACE'

					if not first:
						expr += ' + '
					expr += f't{twist_index} / {n_seg}'
					first = False

				driver.expression = expr

		# Lock Transforms
		for control_name in self.control_names:
			pb = pose_bones[control_name]
			pb.lock_rotation = (True, True, True)
			pb.lock_scale = (True, True, True)

		for twist_name in self.twist_names or []:
			pb = pose_bones[twist_name]
			pb.color.palette = prefs.ik_bone_color
			pb.lock_location = (True, True, True)
			pb.lock_rotation = (True, False, True)
			pb.lock_scale = (True, True, True)
			pb.rotation_mode = 'XYZ'

		return self