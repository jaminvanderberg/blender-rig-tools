from dataclasses import dataclass, field
from typing import Any

from rigtools.armature_settings import get_armature_settings
from rigtools.assemblies.ik_assembly import IKAssemblyOptions
from rigtools.assemblies.template_options import resolve_template_options
from rigtools.assemblies.template_validation import validate_assembly_templates
from rigtools.tool.ik_parent import IKParentTarget
from rigtools.tool.twist_bones import TwistSegment, FALLOFF, twist_source_types


@dataclass(frozen=True)
class IKTemplate:
	label: str
	description: str
	icon: str
	options: dict[str, Any]
	redo_fields: tuple[str, ...] = ()
	field_labels: dict[str, str] = field(default_factory=dict)
	show_dialog: bool = False


IK_TEMPLATES = {
	"arm": IKTemplate(
		label="Arm",
		description="Humanoid arm. Works best with 3 bones.",
		icon="CON_CHILDOF",
		options={
			"limb_property_base_name": "arm",
			"add_tweak_bones": True,
			"ik_bone_count": 3,
			"add_rotation_isolation": True,
			"inherit_scale_from_root": True,
			"ik_type": "IK",
			"pole_distance": 0.25,
			"tweak_relationship": "STRETCH_TO",
			"fk_widget": "FK",
			"tip_widget": "CIRCLE",
			"fk_end_widget": "CIRCLE",
			"enable_snapping": True,
			"ik_parent": True,
			"ik_parents": ("root", "torso", "hips", "chest", "head"),
			"use_twist_bones": True,
			"twist_segments": (
				{"name": "Arm", "index": 0, "source": "SELF", "falloff": "ROOT"},
				{"name": "Forearm", "index": 1, "source": "CHILD", "falloff": "LINEAR"},
			),
			"twist_bone_count": 4,
			"create_master_controllers": False,
		},
		redo_fields=(
			"add_tweak_bones",
			"fk_widget",
			"fk_end_widget",
			"ik_bone_count",
			"add_rotation_isolation",
			"inherit_scale_from_root",
			"use_twist_bones",
			"twist_bone_count",
			"twist_segments",
			"fk_end_widget",
		),
		field_labels={
			"fk_end_widget": "Hand FK Widget:",
		},
	),
	"leg": IKTemplate(
		label="Leg",
		description="Humanoid leg. Works best with 4 bones (thigh, shin, foot, toe).",
		icon="CON_KINEMATIC",
		options={
			"limb_property_base_name": "leg",
			"limb_type": "leg",
			"add_tweak_bones": True,
			"add_rotation_isolation": True,
			"inherit_scale_from_root": False,
			"ik_type": "IK",
			"ik_bone_count": 3,
			"pole_distance": 0.5,
			"tweak_relationship": "STRETCH_TO",
			"fk_widget": "FK",
			"tip_widget": "CIRCLE",
			"fk_end_widget": "CIRCLE",
			"enable_snapping": True,
			"ik_parent": True,
			"ik_parents": ("root", "torso", "self"),
			"ik_parent_self_parent_label": "Foot",
			"use_twist_bones": True,
			"twist_segments": (
				{"name": "Thigh", "index": 0, "source": "SELF", "falloff": "SHARP"},
				{"name": "Shin", "index": 1, "source": "NONE", "falloff": "LINEAR"},
			),
			"twist_bone_count": 4,
			"add_foot_roll": True,
			"create_master_controllers": False,
		},
		redo_fields=(
			"add_tweak_bones",
			"fk_widget",
			"ik_bone_count",
			"use_twist_bones",
			"twist_bone_count",
			"twist_segments",
			"add_foot_roll",
			"tip_widget",
			"fk_end_widget",
			"inherit_scale_from_root",
		),
		field_labels={
			"tip_widget": "Toe Widget:",
			"fk_end_widget": "Foot FK Widget:",
		},
	),
	"skirt.spline": IKTemplate(
		label="Skirt - Spline",
		description="Long skirt with a spline IK setup.",
		icon="CURVE_DATA",
		options={
			"limb_property_base_name": "",
			"add_tweak_bones": True,
			"add_rotation_isolation": True,
			"ik_parent": True,
			"ik_parents": ("root", "torso", "hips"),
			"ik_type": "SPLINE",
			"spline_control_count": 3,
			"spline_skip_first": True,
			"spline_skip_last": False,
			"twist_type": "START_END",
			"tweak_relationship": "STRETCH_TO",
			"fk_widget": "RECTANGLE",
			"normalize_fk_widget_scale": True,
			"enable_snapping": False,
			"add_skirt_collision": True,
			"add_skirt_ride": False,
			"create_master_controllers": True,
			"master_controllers_interval": 0,
			"master_controllers_skip_first": True,
			"master_controllers_type": "FK",
			"master_controllers_widget": "RECTANGLE",
		},
		redo_fields=(
			"limb_property_base_name",
			"fk_widget",
			"normalize_fk_widget_scale",
			"taper_fk_widgets",
			"add_rotation_isolation",
			"inherit_scale_from_root",
			"spline_control_count",
			"spline_skip_first",
			"spline_skip_last",
			"twist_type",
			"ik_parent",
			"ik_parents",
			"add_skirt_collision",
			"add_skirt_ride",
			"skirt_legs",
			"create_master_controllers",
			"master_controllers_interval",
			"master_controllers_skip_first",
			"master_controllers_type",
			"master_controllers_widget",
			"tip_widget",
		),
		show_dialog=False,
	),
	"hair.spline": IKTemplate(
		label="Hair - Spline",
		description="Hair with spline IK setup. Intended for ponytails, etc.",
		icon="OUTLINER_DATA_CURVES",
		options={
			"limb_property_base_name": "",
			"add_tweak_bones": True,
			"add_rotation_isolation": True,
			"ik_parent": True,
			"ik_parents": ("root", "torso", "head"),
			"ik_type": "SPLINE",
			"spline_control_count": 3,
			"spline_skip_first": False,
			"spline_skip_last": False,
			"twist_type": "ALL",
			"tweak_relationship": "STRETCH_TO",
			"fk_widget": "CIRCLE",
			"normalize_fk_widget_scale": True,
			"enable_snapping": False,
			"add_skirt_collision": False,
			"add_skirt_ride": False,
			"create_master_controllers": True,
			"master_controllers_interval": 0,
			"master_controllers_skip_first": True,
			"master_controllers_type": "FK",
		},
		redo_fields=(
			"limb_property_base_name",
			"fk_widget",
			"normalize_fk_widget_scale",
			"taper_fk_widgets",
			"add_rotation_isolation",
			"inherit_scale_from_root",
			"spline_control_count",
			"spline_skip_first",
			"spline_skip_last",
			"twist_type",
			"ik_parent",
			"ik_parents",
			"create_master_controllers",
			"master_controllers_interval",
			"master_controllers_skip_first",
			"master_controllers_type",
			"master_controllers_widget",
		),
		show_dialog=False,
	),
	"tail.spline": IKTemplate(
		label="Tail - Spline",
		description="Long skirt with a spline IK setup.",
		icon="IPO_EASE_IN_OUT",
		options={
			"limb_property_base_name": "",
			"add_tweak_bones": True,
			"add_rotation_isolation": True,
			"ik_parent": True,
			"ik_parents": ("root", "torso", "hips"),
			"ik_type": "SPLINE",
			"spline_control_count": 4,
			"spline_skip_first": False,
			"spline_skip_last": False,
			"twist_type": "START_END",
			"tweak_relationship": "STRETCH_TO",
			"fk_widget": "CIRCLE",
			"normalize_fk_widget_scale": True,
			"taper_fk_widgets": True,
			"enable_snapping": False,
			"add_skirt_collision": False,
			"add_skirt_ride": False,
			"create_master_controllers": True,
			"master_controllers_interval": 3,
			"master_controllers_skip_first": True,
			"master_controllers_type": "MASTER",
			"master_controllers_widget": "CIRCLE",
		},
		redo_fields=(
			"limb_property_base_name",
			"fk_widget",
			"normalize_fk_widget_scale",
			"taper_fk_widgets",
			"add_rotation_isolation",
			"inherit_scale_from_root",
			"spline_control_count",
			"spline_skip_first",
			"spline_skip_last",
			"twist_type",
			"ik_parent",
			"ik_parents",
			"create_master_controllers",
			"master_controllers_interval",
			"master_controllers_skip_first",
			"master_controllers_type",
			"master_controllers_widget",
		),
		show_dialog=False,
	),	
}


IK_PARENT_SETTINGS = {
	"root": ("Root", "root_bone_name"),
	"torso": ("Torso", "torso_bone_name"),
	"hips": ("Hips", "hips_bone_name"),
	"chest": ("Chest", "chest_bone_name"),
	"head": ("Head", "head_bone_name"),
}

# Fields the template redo panel / operator may expose.
REDO_PROPERTIES = {
	"limb_property_base_name",
	"add_tweak_bones",
	"add_rotation_isolation",
	"inherit_scale_from_root",
	"ik_type",
	"pole_distance",
	"spline_control_count",
	"spline_skip_first",
	"spline_skip_last",
	"twist_type",
	"tweak_relationship",
	"fk_widget",
	"normalize_fk_widget_scale",
	"taper_fk_widgets",
	"enable_snapping",
	"ik_parent",
	"ik_parents",
	"use_twist_bones",
	"twist_bone_count",
	"twist_segments",
	"add_foot_roll",
	"ik_bone_count",
	"tip_widget",
	"fk_end_widget",
	"add_skirt_collision",
	"add_skirt_ride",
	"skirt_legs",
	"create_master_controllers",
	"master_controllers_interval",
	"master_controllers_skip_first",
	"master_controllers_type",
	"master_controllers_widget",
}


def get_ik_template(template_id: str) -> IKTemplate | None:
	return IK_TEMPLATES.get(template_id)


_VALID_TWIST_SOURCES = {item[0] for item in twist_source_types}
_VALID_TWIST_FALLOFFS = set(FALLOFF)


def resolve_twist_segments(raw_segments) -> list[TwistSegment]:
	"""Convert template/JSON segment dicts into TwistSegment values."""
	segments = []
	for entry in raw_segments or []:
		if isinstance(entry, TwistSegment):
			segments.append(entry)
			continue
		segments.append(
			TwistSegment(
				index=int(entry["index"]),
				source=entry["source"],
				falloff=entry.get("falloff", "LINEAR"),
				name=entry.get("name", ""),
			)
		)
	return segments


def _validate_ik_template_rules(template_id: str, template: IKTemplate):
	options = resolve_template_options(IKAssemblyOptions, template.options)
	valid_parent_names = set(IK_PARENT_SETTINGS) | {"self"}
	parent_names = options["ik_parents"]
	if not isinstance(parent_names, (tuple, list)) or not all(
		isinstance(parent_name, str) for parent_name in parent_names
	):
		raise ValueError(f"IK template '{template_id}' parents must be a list of special names")

	invalid_parent_names = set(parent_names) - valid_parent_names
	if invalid_parent_names:
		raise ValueError(
			f"IK template '{template_id}' has unknown IK parents: {sorted(invalid_parent_names)}"
		)
	if options["ik_parent"] and not parent_names:
		raise ValueError(f"IK template '{template_id}' enables IK parents without defining any")
	if "self" in parent_names and options["ik_type"] != "IK":
		raise ValueError(f"IK template '{template_id}' can only use the self parent with standard IK")

	if options["use_twist_bones"]:
		if options["ik_type"] != "IK":
			raise ValueError(f"IK template '{template_id}' can only use twist bones with standard IK")
		if options["twist_bone_count"] < 2:
			raise ValueError(f"IK template '{template_id}' twist_bone_count must be >= 2")
		segments = resolve_twist_segments(options["twist_segments"])
		if not segments:
			raise ValueError(f"IK template '{template_id}' enables twist bones without segments")
		indexes = [segment.index for segment in segments]
		if len(indexes) != len(set(indexes)):
			raise ValueError(f"IK template '{template_id}' twist segment indexes must be unique")
		for segment in segments:
			if segment.source not in _VALID_TWIST_SOURCES:
				raise ValueError(
					f"IK template '{template_id}' has unknown twist source '{segment.source}'"
				)
			if segment.falloff not in _VALID_TWIST_FALLOFFS:
				raise ValueError(
					f"IK template '{template_id}' has unknown twist falloff '{segment.falloff}'"
				)


def validate_ik_templates():
	validate_assembly_templates(
		IK_TEMPLATES,
		IKAssemblyOptions,
		kind="IK",
		redo_properties=REDO_PROPERTIES,
		extra_check=_validate_ik_template_rules,
	)


def resolve_ik_parents(context, parent_names):
	if len(parent_names) != len(set(parent_names)):
		raise ValueError("IK template parent names must be unique.")

	settings = get_armature_settings(context.object.data, context)
	parents = []

	for parent_name in parent_names:
		if parent_name == "self":
			continue

		label, setting_name = IK_PARENT_SETTINGS[parent_name]
		bone_name = getattr(settings, setting_name)
		if not bone_name:
			raise ValueError(f"{label} bone is not configured in the armature settings.")
		if bone_name not in context.object.data.bones:
			raise ValueError(f"{label} bone '{bone_name}' was not found.")

		parents.append(IKParentTarget(label=label, bone=bone_name))

	return parents, "self" in parent_names
