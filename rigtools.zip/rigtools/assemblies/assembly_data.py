from dataclasses import asdict, dataclass, is_dataclass
import json
import uuid
import bpy
from bpy.props import StringProperty, CollectionProperty, BoolProperty, EnumProperty
from bpy.types import PropertyGroup
from rigtools.armature_settings import get_armature_settings
from rigtools.assemblies.limb_collections import LimbCollectionMap
from rigtools.assemblies.tool_data.bone_style import BoneStyle
from rigtools.utils.naming import does_match_def_name, limb_group_label

def find_assemblies(armature_data, bone_names, *, include_org_states=True, include_mechanism_bones=True):
	wanted = set(bone_names)
	assemblies = []
	for assembly in armature_data.rigtools_assemblies:
		names = set()
		if include_org_states:
			names.update(o.name for o in assembly.org_states)
		if include_mechanism_bones:
			names.update(b.name for b in assembly.mechanism_bones)
		if names & wanted:
			assemblies.append(assembly)
	return assemblies

def find_org_state(armature_data, bone_name):
	"""The stored org_state for the first assembly containing bone_name, or None"""
	for assembly in armature_data.rigtools_assemblies:
		for state in assembly.org_states:
			if state.name == bone_name:
				return state
	return None

# Config payloads that tools write back into options_json; they hold per-chain bone names
CONFIG_OPTION_KEYS = {"ik_parent_config", "skirt_collision", "skirt_ride"}

def find_similar_assemblies(armature_data, source, mode, include_mirror):
	"""mode 'LIMB': same limb name. mode 'CONFIG': also the same options.
	include_mirror matches any side, otherwise only the source's side. Yields the source assembly too."""
	source_options = source.get_options()
	source_config = {k: v for k, v in source_options.items() if k not in CONFIG_OPTION_KEYS}

	for assembly in armature_data.rigtools_assemblies:
		if not include_mirror and assembly.side != source.side:
			continue
		if assembly.limb != source.limb:
			continue
		options = assembly.get_options()
		if mode == 'CONFIG' and {k: v for k, v in options.items() if k not in CONFIG_OPTION_KEYS} != source_config:
			continue
		yield assembly

class RoleRef(PropertyGroup):
	name: StringProperty()

class BoneRef(PropertyGroup):
	name: StringProperty()
	roles: CollectionProperty(type=RoleRef)
	style_json: StringProperty()
	palette: StringProperty() # resolved widget color

	def get_style(self) -> BoneStyle:
		return BoneStyle.from_json(self.style_json)

	def set_style(self, style: BoneStyle):
		self.style_json = style.to_json()

	def add_style(self, style: BoneStyle):
		stored = self.get_style()
		stored.append(style)
		self.set_style(stored)

class OrgState(PropertyGroup):
	name: StringProperty() # ORG bone name
	parent: StringProperty()
	use_connect: BoolProperty()

class AssemblyProperty(PropertyGroup):
	name: StringProperty()
	role: StringProperty()
	qualifier: StringProperty()

class AssemblyObject(PropertyGroup):
	name: StringProperty()

class AssemblyParent(PropertyGroup):
	label: StringProperty()
	bone: StringProperty()

class ReparentRule(PropertyGroup):
	from_bone: StringProperty()
	to_bone: StringProperty()

class AssemblyData(PropertyGroup):
	uid: StringProperty()
	name: StringProperty()
	limb: StringProperty()	
	side: StringProperty(default="C")
	ui_label: StringProperty()
	assembly_type: EnumProperty(items=[
		('FK', "FK", ""),
		('IK', "IK", ""),
		('TORSO', "TORSO", ""),
		('PALM', "PALM", ""),
	])
	template_id: StringProperty()
	template_name: StringProperty()

	org_states: CollectionProperty(type=OrgState)
	twist_states: CollectionProperty(type=OrgState)
	# Cleared by migrate_4_to_5; kept so that migration can run. Tip handoff uses reparent_rules.
	org_children: CollectionProperty(type=OrgState)

	mechanism_bones: CollectionProperty(type=BoneRef)
	properties: CollectionProperty(type=AssemblyProperty)
	objects: CollectionProperty(type=AssemblyObject)
	reparent_rules: CollectionProperty(type=ReparentRule)
	
	ik_parents: CollectionProperty(type=AssemblyParent)

	options_json: StringProperty()
	config_defaults_json: StringProperty()

	def apply_tool(self, context, tool, limb_collections, prior_configs={}):
		obj = context.object
		armature_data = obj.data
		if obj.mode != 'POSE':
			bpy.ops.object.mode_set(mode='POSE')

		pose_bones = obj.pose.bones
		prior_styles = prior_configs.get("bone_styles", {})
		prior_values = prior_configs.get("property_values", {})
		prop_bone = pose_bones.get(get_armature_settings(armature_data, context).property_bone_name)

		# Mechanism bones and collections
		for bone_ref in tool.mechanism_bones:
			mech_bone = self.mechanism_bones.add()
			mech_bone.name = bone_ref.name
			roles = []
			for role in bone_ref.roles:
				mech_role = mech_bone.roles.add()
				mech_role.name = role
				roles.append(role)

			limb_collections.add_bone(armature_data, bone_ref.name, roles)

			# Bone Color
			style = tool.mechanism_bones.styles[bone_ref.name]
			if style.color is None:
				color_roles = [role for role in bone_ref.roles if role != 'mch']
				if len(color_roles) == 1:
					style.color = color_roles[0]

		# Bone Styles
		mech_bones_by_name = {row.name: row for row in self.mechanism_bones}
		for bone_name, style in tool.mechanism_bones.styles.items():
			mech_bone = mech_bones_by_name.get(bone_name)
			if mech_bone is None:
				raise ValueError(f"{type(tool).__name__} styled '{bone_name}', which isn't in assembly '{self.name}'")

			pose_bone = pose_bones[bone_name]
			# Mirror sided widgets with a class (foot, hand, toe)
			if style.widget_class and limb_collections.side == "R":
				x, y, z = style.scale or (1.0, 1.0, 1.0)
				style.scale = (-x, y, z)
			# Standard widgets are shared, so they aren't added to objects
			style.apply(context, pose_bone, limb_collections.side)
			if style.color is not None:
				mech_bone.palette = pose_bone.color.palette

			prior_style = prior_styles.get(bone_name)
			if prior_style:
				prior_style.apply(pose_bone)

			mech_bone.add_style(style)

		# Properties
		for prop in getattr(tool, 'tool_properties', ()):
			assembly_prop = self.properties.add()
			assembly_prop.name = prop.name
			assembly_prop.role = prop.role
			assembly_prop.qualifier = prop.qualifier

			# Restore previous value
			prior = prior_values.get(prop.name)
			if prior is not None and prop.name in prop_bone:
				items = prop_bone.id_properties_ui(prop.name).as_dict().get("items")
				if not items or prior < len(items):
					prop_bone[prop.name] = prior

		for object_name in getattr(tool, 'object_names', ()):
			assembly_obj = self.objects.add()
			assembly_obj.name = object_name

		if hasattr(tool, 'twist_states'):
			for state in tool.twist_states:
				row = self.twist_states.add()
				row.name = state['name']
				row.parent = state['parent']
				row.use_connect = state['use_connect']

		if hasattr(tool, 'reparent_rules'):
			for from_bone, to_bone in tool.reparent_rules:
				row = self.reparent_rules.add()
				row.from_bone = from_bone
				row.to_bone = to_bone

		return self

	def get_bones_by_role(self, role):
		names = []
		for bone_ref in self.mechanism_bones:
			for role_ref in bone_ref.roles:
				if role_ref.name == role:
					names.append(bone_ref.name)
		return names

	def get_options(self):
		return json.loads(self.options_json or "{}")

	def get_config_defaults(self):
		return json.loads(self.get("config_defaults_json") or "{}")

	def get_chain(self):
		return [bone.name for bone in self.org_states]

def create_assembly_data(obj, org_bones, name, assembly_type, template_id, template_name, options, side, uid=None):
	assemblies = find_assemblies(obj.data, org_bones)
	if assemblies:
		raise ValueError(f"Selected bones are being used by other assemblies: {', '.join(a.name for a in assemblies)}")
	def_bones = [name for name in org_bones if does_match_def_name(name)]
	if def_bones:
		raise ValueError(f"{', '.join(def_bones)} are DEF bones. Use the ORG bones.")

	assembly_data = obj.data.rigtools_assemblies.add()
	assembly_data.uid = uid or str(uuid.uuid4())
	assembly_data.name = name
	assembly_data.side = side
	assembly_data.assembly_type = assembly_type
	assembly_data.options_json = _options_to_json(options)
	assembly_data.template_id = template_id
	assembly_data.template_name = template_name

	limb = getattr(options, 'limb', "") or ""
	assembly_data.limb = limb.strip()
	assembly_data.ui_label = limb_group_label(assembly_data.limb, side) or name

	bones = obj.data.edit_bones if obj.mode == 'EDIT' else obj.data.bones

	for bone_name in org_bones:
		bone = bones[bone_name]
		row = assembly_data.org_states.add()
		row.name = bone_name
		row.parent = bone.parent.name if bone.parent else ""
		row.use_connect = bone.use_connect

	parents = getattr(options, 'ik_parents', None) or []
	for parent in parents:
		row = assembly_data.ik_parents.add()
		row.label = parent.label
		row.bone = parent.bone

	return assembly_data

def find_assembly(obj, uid):
	for assembly in obj.data.rigtools_assemblies:
		if assembly.uid == uid:
			return assembly
	return None

def styled_bone_refs(armature_data):
	"""{bone name: the mechanism bone row that styled it}, for every bone an assembly styled"""
	return {
		bone_ref.name: bone_ref
		for assembly in armature_data.rigtools_assemblies
		for bone_ref in assembly.mechanism_bones
		if bone_ref.style_json
	}

def _options_to_json(options):
	data = asdict(options) if is_dataclass(options) else dict(options)
	data.pop('ik_parents', None) # store separately
	data.pop('limb', None) # stored on the assembly
	return json.dumps(data)

@dataclass
class AssemblyChain:
	assembly_uid: str
	tools: list
	limb_collections: LimbCollectionMap
	
classes = (
	RoleRef,
	BoneRef,
	OrgState,
	AssemblyProperty,
	AssemblyObject,
	AssemblyParent,
	ReparentRule,
	AssemblyData,
	LimbCollectionMap,
)

def register():
	for cls in classes:
		bpy.utils.register_class(cls)
	bpy.types.Armature.rigtools_assemblies = CollectionProperty(type=AssemblyData)
	bpy.types.Armature.rigtools_limb_collections = CollectionProperty(type=LimbCollectionMap)

def unregister():
	del bpy.types.Armature.rigtools_assemblies
	del bpy.types.Armature.rigtools_limb_collections
	for cls in reversed(classes):
		bpy.utils.unregister_class(cls)
